"""content_annotation URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from app import views
from django.urls import path

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'content_annotation/post_characteristics.html', views.post_characteristics, name='post_characteristics'),
    url(r'content_annotation/support_characteristics.html', views.support_characteristics, name='support_characteristics'),
    url(r'content_annotation/highlight_seeker.html', views.highlight_seeker, name='highlight_seeker'),
    url(r'content_annotation/highlight_responder.html', views.highlight_responder, name='highlight_responder'),
    url(r'content_annotation/success.html', views.success, name='success')
]
