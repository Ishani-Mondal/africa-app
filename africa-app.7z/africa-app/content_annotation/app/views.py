import os

import mysql.connector

from django.shortcuts import render
from django.http import HttpResponse

from django.core.files.storage import FileSystemStorage

from random import shuffle
# from dishelper.settings import BASE_DIR

# import tarfile
# from io import BytesIO

# print('Connected to Database')


def success(request):
	if request.method == 'POST':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()

		pair_Id = request.POST.get('pair_Id', None)
		s_content = request.POST.get('s_content', None)
		r_content = request.POST.get('r_content', None)

		skip = request.POST.get('skip', None)

		if skip == 'T':
			print('Skipping!')
			skip_reason = request.POST.getlist('skip_annotation', None)
			class_suggestion = request.POST.get('class_suggestion', None)

			if skip_reason != None:
				reasons = ''

				for elem in skip_reason:
					reasons = str(elem) + ',' + reasons.strip()

				sql = "DELETE FROM SkipReason WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)

				if class_suggestion == None:
					class_suggestion = ''


				sql = "INSERT INTO SkipReason (PairId, Reason, Class_Suggestion) VALUES (%s, %s, %s)"
				val = (pair_Id, reasons, class_suggestion)
				mycursor.execute(sql, val)

				sql = "UPDATE Posts SET annotation_status = 'P' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)

				mydb.commit()
				mycursor.close()

				return render(request, "app/success.html", {'out': [pair_Id, s_content, r_content], 'next': int(pair_Id) + 1, 'success_type': 'Annotation Skipped!'})

		mycursor = mydb.cursor()
		sql = "UPDATE Messages set annotation_status='Y' where PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		R_English = request.POST.getlist('informational', None)
		R_Swahili = request.POST.getlist('emotional', None)
		R_Sheng = request.POST.getlist('instrumental', None)
		R_Other = request.POST.getlist('esteem', None)

		mycursor = mydb.cursor()

		sql = "DELETE From Language_Annotation where PairId = "+str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()


		mycursor = mydb.cursor()
		if R_English != None:
			for elem in R_English:
				sql = "INSERT INTO Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'English')
				mycursor.execute(sql, val)

		if R_Swahili != None:
			for elem in R_Swahili:
				sql = "INSERT INTO Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id,  elem, 'Swahili')
				mycursor.execute(sql, val)

		if R_Sheng != None:
			for elem in R_Sheng:
				sql = "INSERT INTO Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'Sheng')
				mycursor.execute(sql, val)

		if R_Other != None:
			for elem in R_Other:
				sql = "INSERT INTO Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s,%s)"
				val = (pair_Id, elem, 'Other')
				mycursor.execute(sql, val)
		
		
		mydb.commit()
		mycursor.close()

		return render(request, "app/success.html", {'out': [pair_Id, s_content, r_content], 'next': int(pair_Id) + 1, 'success_type': 'Annotation Successful!'})


def highlight_responder(request):
	if request.method == 'POST':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()

		refresh = request.POST.get('refresh', None)

		pair_Id = request.POST.get('pair_Id', None)
		s_content = request.POST.get('s_content', None)
		r_content = request.POST.get('r_content', None)

		if refresh == 'T':
			return_dict = {'out': [pair_Id, s_content, r_content],
					 	'IAIP': request.POST.get('IAIP', None),
					 	'IAIS': request.POST.get('IAIS', None),
					 	'IMP': request.POST.get('IMP',None),
					 	'IMS': request.POST.get('IMS',None),
					 	'IHLP': request.POST.get('IHLP',None),
						'IHLS': request.POST.get('IHLS',None),
						'IPLP': request.POST.get('IPLP',None),
						'IPLS': request.POST.get('IPLS',None),
						'IOIP': request.POST.get('IOIP',None),
						'IOIS': request.POST.get('IOIS',None),
						'EE': request.POST.get('EE',None),
						'EIH': request.POST.get('EIH',None),
						'ENF': request.POST.get('ENF',None),
						'EEH': request.POST.get('EEH',None),
						'GW': request.POST.get('GW',None),
						'GCSI': request.POST.get('GCSI',None),
						'GCG': request.POST.get('GCG',None),
						'ACK': request.POST.get('ACK',None),
						'OTH': request.POST.get('OTH',None)}

			return render(request, "app/highlight_responder.html", return_dict)

		IAIP = request.POST.get('IAIP', None)
		IAIS = request.POST.get('IAIS', None)
		IMP = request.POST.get('IMP', None)
		IMS = request.POST.get('IMS', None)
		IHLP = request.POST.get('IHLP', None)
		IHLS = request.POST.get('IHLS', None)
		IPLP = request.POST.get('IPLP', None)

		IPLS = request.POST.get('IPLS', None)
		IOIP = request.POST.get('IOIP', None)
		IOIS = request.POST.get('IOIS', None)
		EE = request.POST.get('EE', None)
		EIH = request.POST.get('EIH', None)
		ENF = request.POST.get('ENF', None)
		EEH = request.POST.get('EEH', None)
		GW = request.POST.get('GW', None)
		GCSI = request.POST.get('GCSI', None)
		GCG = request.POST.get('GCG', None)
		ACK = request.POST.get('ACK', None)
		OTH = request.POST.get('GCG', None)


		IAI_L = request.POST.getlist('informational', None)
		IHL_L = request.POST.getlist('instrumental', None)
		IPL_L = request.POST.getlist('emotional', None)
		IMP_L = request.POST.getlist('esteem', None)
		IOI_L = request.POST.getlist('network', None)

		ENF_L = request.POST.getlist('likings', None)
		EIH_L = request.POST.getlist('hope', None)
		EE_L = request.POST.getlist('empathy', None)
		EEH_L = request.POST.getlist('happiness', None)

		GW_L = request.POST.getlist('group', None)

		GCSI_L = request.POST.getlist('interaction', None)
		ACK_L = request.POST.getlist('ack', None)
		
		sql = "DELETE FROM Category_Highlight WHERE PairId = " + pair_Id
		mycursor.execute(sql)

		if IAI_L!=None:
			for elem in IAI_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IAI')
				mycursor.execute(sql, val)

		if IHL_L!=None:
			for elem in IHL_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IHL')
				mycursor.execute(sql, val)

		if IMP_L!=None:
			for elem in IMP_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IMP')
				mycursor.execute(sql, val)

		if IPL_L!=None:
			for elem in IPL_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IPL')
				mycursor.execute(sql, val)

		if IOI_L!=None:
			for elem in IOI_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IOI')
				mycursor.execute(sql, val)

		if ENF_L!=None:
			for elem in ENF_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'ENF')
				mycursor.execute(sql, val)

		if EE!=None:
			for elem in IAI:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'EE')
				mycursor.execute(sql, val)

		if EIH_L!=None:
			for elem in EIH_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'EIH')
				mycursor.execute(sql, val)

		if EEH_L!=None:
			for elem in EEH_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'EEH')
				mycursor.execute(sql, val)

		if GW_L!=None:
			for elem in GW_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'GW')
				mycursor.execute(sql, val)

		if GCSI_L!=None:
			for elem in GCSI_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'GCSI')
				mycursor.execute(sql, val)

		if ACK_L!=None:
			for elem in ACK_L:
				sql = "INSERT INTO Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'ACK')
				mycursor.execute(sql, val)

		mydb.commit()
		mycursor.close()

		return_dict = {'out': [pair_Id, s_content, r_content],
					 	'IAIP': IAIP,
					 	'IAIS': IAIS, 
					 	'IMP': IMP,
					 	'IMS': IMS,
					 	'IHLP': IHLP,
						'IHLS': IHLS,
						'IPLP': IPLP,
						'IPLS': IPLS,
						'IOIP': IOIP,
						'IOIS': IOIS,
						'EE': EE,
						'EIH': EIH,
						'ENF': ENF,
						'EEH': EEH,
						'GW': GW,
						'GCSI': GCSI,
						'GCG': GCG,
						'ACK': ACK,
						'OTH': OTH}

		return render(request, "app/highlight_responder.html", return_dict)



def highlight_seeker(request):
	if request.method == 'POST':

		refresh = request.POST.get('refresh', None)

		pair_Id = request.POST.get('pair_Id', None)
		s_content = request.POST.get('s_content', None)
		r_content = request.POST.get('r_content', None)
        #print(s_content)
		if refresh == 'T':

			return_dict = {'out': [pair_Id, s_content, r_content.split(",")[-1]],
					 	'IAIP': request.POST.get('IAIP', None),
					 	'IAIS': request.POST.get('IAIS', None),
					 	'IMP': request.POST.get('IMP',None),
					 	'IMS': request.POST.get('IMS',None),
					 	'IHLP': request.POST.get('IHLP',None),
						'IHLS': request.POST.get('IHLS',None),
						'IPLP': request.POST.get('IPLP',None),
						'IPLS': request.POST.get('IPLS',None),
						'IOIP': request.POST.get('IOIP',None),
						'IOIS': request.POST.get('IOIS',None),
						'EE': request.POST.get('EE',None),
						'EIH': request.POST.get('EIH',None),
						'ENF': request.POST.get('ENF',None),
						'EEH': request.POST.get('EEH',None),
						'GW': request.POST.get('GW',None),
						'GCSI': request.POST.get('GCSI',None),
						'GCG': request.POST.get('GCG',None),
						'ACK': request.POST.get('ACK',None),
						'OTH': request.POST.get('OTH',None)}

			return render(request, "app/highlight_seeker.html", return_dict)


		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()

		IAIP = request.POST.get('IAIP', None)
		IAIS = request.POST.get('IAIS', None)
		IMP = request.POST.get('IMP', None)
		IMS = request.POST.get('IMS', None)
		IHLP = request.POST.get('IHLP', None)
		IHLS = request.POST.get('IHLS', None)
		IPLP = request.POST.get('IPLP', None)

		IPLS = request.POST.get('IPLS', None)
		IOIP = request.POST.get('IOIP', None)
		IOIS = request.POST.get('IOIS', None)
		EE = request.POST.get('EE', None)
		EIH = request.POST.get('EIH', None)
		ENF = request.POST.get('ENF', None)
		EEH = request.POST.get('EEH', None)
		GW = request.POST.get('GW', None)
		GCSI = request.POST.get('GCSI', None)
		GCG = request.POST.get('GCG', None)
		ACK = request.POST.get('ACK', None)
		OTH = request.POST.get('GCG', None)


		return_dict = {'out': [pair_Id, s_content, r_content.split(",")[-1]],
					 	'IAIP': IAIP,
					 	'IAIS': IAIS, 
					 	'IMP': IMP,
					 	'IMS': IMS,
					 	'IHLP': IHLP,
						'IHLS': IHLS,
						'IPLP': IPLP,
						'IPLS': IPLS,
						'IOIP': IOIP,
						'IOIS': IOIS,
						'EE': EE,
						'EIH': EIH,
						'ENF': ENF,
						'EEH': EEH,
						'GW': GW,
						'GCSI': GCSI,
						'GCG': GCG,
						'ACK': ACK,
						'OTH': OTH}

		return render(request, "app/highlight_seeker.html", return_dict)

def support_characteristics(request):

	if request.method == 'POST':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()

		S_Post = request.POST.getlist('S_Post', None)

		print('S_Post:', S_Post, type(S_Post))

		pair_Id = request.POST.get('pair_Id', None)
		s_content = request.POST.get('s_content', None)
		r_content = request.POST.get('r_content', None)
		sentiment = request.POST.get('Mental_Health', None)
		print('pair_Id:', pair_Id)
		print('Sentiment:',sentiment)
		if sentiment == 'Negative':
			sql = "UPDATE Messages SET Sentiment = 'N' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		elif sentiment == 'Non-negative':
			sql = "UPDATE Messages SET Sentiment = 'NN' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)

		mydb.commit()
		mycursor.close()

		IAIP=0
		IAIS=0
		IMP=0
		IMS=0
		IHLP=0
		IHLS=0
		IPLP=0
		IPLS=0
		IOIP=0
		IOIS=0
		EE=0
		EIH=0
		ENF=0
		EEH=0
		GW=0
		GCSI=0
		GCG=0
		ACK=0
		OTH=0

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET EEH = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET ENF = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET EIH = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET EE = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IOIS = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IOIP = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IPLS = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IPLP = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IHLS = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()

		sql = "UPDATE MESSAGE_CATEGORIES SET IHLP = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IMS = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IMP = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IAIS = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET GW = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET GCSI = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET GCG = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET ACK = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql = "UPDATE MESSAGE_CATEGORIES SET IAIP = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()

		sql = "UPDATE MESSAGE_CATEGORIES SET OTH = 'F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		for s_tag in S_Post:
			if(s_tag=='IAIP'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IAIP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IAIP=1

			if(s_tag=='IAIS'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IAIS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IAIS=1
			
			if(s_tag=='IMP'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IMP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IMP=1

			if(s_tag=='IMS'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IMS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IMS=1

			if(s_tag=='IHLP'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IHLP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IHLP=1

			if(s_tag=='IHLS'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IHLS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IHLS=1

			if(s_tag=='IPLP'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IPLP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IPLP=1

			if(s_tag=='IPLS'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IPLS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IPLS=1


			if(s_tag=='IOIP'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IOIP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IOIP=1

			if(s_tag=='IOIS'):
				sql = "UPDATE MESSAGE_CATEGORIES SET IOIS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				IOIS=1

			if(s_tag=='EE'):
				sql = "UPDATE MESSAGE_CATEGORIES SET EE = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				EE=1

			if(s_tag=='EIH'):
				sql = "UPDATE MESSAGE_CATEGORIES SET EIH = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				EIH=1

			if(s_tag=='ENF'):
				sql = "UPDATE MESSAGE_CATEGORIES SET ENF = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				ENF=1

			if(s_tag=='EEH'):
				sql = "UPDATE MESSAGE_CATEGORIES SET EEH = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				EEH=1

			if(s_tag=='GW'):
				sql = "UPDATE MESSAGE_CATEGORIES SET GW = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				GW=1

			if(s_tag=='GCSI'):
				sql = "UPDATE MESSAGE_CATEGORIES SET GCSI = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				GCSI=1

			if(s_tag=='GCG'):
				sql = "UPDATE MESSAGE_CATEGORIES SET GCG = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				GCG=1

			if(s_tag=='ACK'):
				sql = "UPDATE MESSAGE_CATEGORIES SET ACK = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				ACK=1

			if(s_tag=='OTH'):
				sql = "UPDATE MESSAGE_CATEGORIES SET OTH = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				OTH=1

		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		if sentiment == 'Negative':
			sql = "UPDATE Messages SET Sentiment = 'N' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		else:
			sql = "UPDATE Messages SET Sentiment = 'NN' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		
		return_dict = {'out': [pair_Id, s_content, r_content],
					 	'IAIP': IAIP,
					 	'IAIS': IAIS, 
					 	'IMP': IMP,
					 	'IMS': IMS,
					 	'IHLP': IHLP,
						'IHLS': IHLS,
						'IPLP': IPLP,
						'IPLS': IPLS,
						'IOIP': IOIP,
						'IOIS': IOIS,
						'EE': EE,
						'EIH': EIH,
						'ENF': ENF,
						'EEH': EEH,
						'GW': GW,
						'GCSI': GCSI,
						'GCG': GCG,
						'ACK': ACK,
						'OTH': OTH}

		return render(request, "app/support_characteristics.html", return_dict)


def post_characteristics(request):
    #return HttpResponse('Hello world !')
    
	if request.method == 'GET':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()
		#mycursor.execute("SELECT * from Posts")
		pair_Id = request.GET.get('post')
		mycursor.execute("SELECT PairId, S_Content, R_Content, annotation_status FROM Messages WHERE PairId = " + str(pair_Id))
		myresult = mycursor.fetchall()
		#print(myresult)
		shuffle(myresult)

		curr_pair = myresult[0]

		pair_id = curr_pair[0]
		previous = curr_pair[1]
		s_content=previous.split(":::")[1:]

		final={}
		for index, elem in enumerate(s_content):
			#print(index, elem)
			final[index+1]={}
			final[index+1]['Date']=elem.split(";")[0]
			final[index+1]['Time']=elem.split(";")[1]
			final[index+1]['User']=elem.split(";")[2]
			final[index+1]['Message']=elem.split(";")[3]

		s_content=final

		target = curr_pair[2]
		r_content=target.split(":::")
		final={}
		for index, elem in enumerate(r_content):
			#print(index, elem)
			final[index+1]={}
			final[index+1]['Date']=elem.split(";")[0]
			final[index+1]['Time']=elem.split(";")[1]
			final[index+1]['User']=elem.split(";")[2]
			final[index+1]['Message']=elem.split(";")[3]

		r_content=final
		annotation_status = curr_pair[3]

		mycursor.close()
		#return render(request, "app/post_characteristics.html", {'out': '', 'annotation_status': annotation_status})
		return render(request, "app/post_characteristics.html", {'out': [pair_id, s_content, r_content], 'annotation_status': annotation_status})

	else:
		return render(request, "app/post_characteristics.html", {'out': ['pair_id', 's_content', 'r_content']})
    