drop database content_annotation_mh;
create database content_annotation_mh;
use content_annotation_mh;

drop table Post_Characteristics;
drop table Support_Characteristics;
drop table Highlight;
drop table Posts;
drop table SkipReason;

create table Posts(
	PairId int NOT NULL AUTO_INCREMENT,
    S_PostId varchar(256) NOT NULL,
    R_PostId varchar(256) NOT NULL,
	S_UserId varchar(256),
    R_UserId varchar(256),
    S_Content TEXT,
    R_Content TEXT,
    Mental_Health ENUM('Y', 'N'),
    annotation_status ENUM('Y', 'N', 'P') DEFAULT 'N',
    primary key(PairId)
);

create table Post_Characteristics(
	PairId int NOT NULL,
	S_Self ENUM('T', 'F') DEFAULT 'F',
    S_Else ENUM('T', 'F') DEFAULT 'F',
    S_Generic ENUM('T', 'F') DEFAULT 'F',
    S_Status ENUM('T', 'F') DEFAULT 'F',
    R_Supportive ENUM('T', 'F') DEFAULT 'F',
    R_Unsupportive ENUM('T', 'F') DEFAULT 'F',
    R_Explore ENUM('T', 'F') DEFAULT 'F',
    R_PD ENUM('T', 'F') DEFAULT 'F',
    R_Greetings ENUM('T', 'F') DEFAULT 'F'
);

create table Support_Characteristics(
	PairId int NOT NULL,
    S_Background ENUM('Y', 'N'),
    S_Likings ENUM('Y', 'N'),
    S_State ENUM('Y', 'N'),
    S_Query ENUM('Y', 'N'),
    S_Support varchar(256),
    R_Issue ENUM('Y', 'N'),
    R_Support varchar(256),
    R_Unsupport varchar(256),
    R_Tentative ENUM('T', 'N', 'C')
);

create table Highlight(
	PairId varchar(256) NOT NULL,
    PostType ENUM('S', 'R'),
    C_Highlighted TEXT,
    Tag varchar(256)
);

create table SkipReason(
	PairID varchar(256) NOT NULL,
    Reason TEXT,
    Class_Suggestion TEXT
);