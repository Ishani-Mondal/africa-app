import mysql.connector

mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )
mycursor = mydb.cursor()
mycursor.execute("SELECT PairId, S_Content, R_Content, annotation_status FROM PILOT_A1_Messages")
myresult = mycursor.fetchall()

dictionary={}
for elem in myresult:
    dictionary[elem[0]]={}
    dictionary[elem[0]]['s_content']=elem[1]
    dictionary[elem[0]]['r_content']=elem[2]


for key, val in dictionary.items():
    for v1, v2 in val.items():
        print(key, v1, v2)

#import pickle
#with open('dict.pickle', 'wb') as handle:
    #pickle.dump(dictionary, handle, protocol=pickle.HIGHEST_PROTOCOL)

#dbfile = open('dict.pickle', 'ab') 
      
# source, destination 
#pickle.dump(dictionary, dbfile)                      
import json
with open('dictionary.json', 'w') as fp:
    json.dump(dictionary, fp)


import pandas as pd
df = pd.read_excel (r'Pilot_G1_Message.xlsx')
messages=[]
for index, row in df.iterrows():
    messages.append(str(row['Date'])+";"+str(row['Time'])+";"+str(row['Sender'])+";"+str(row['Message']))

pairId=[]
scontent=[]
rcontent=[]
s1=[]
r1=[]
s2=[]
r2=[]
sentiment=[]
annotation_status=[]
category=[]

for i, elem in enumerate(messages):
    pairId.append(i+1)
    if(i<10):
        scontent.append(str(":::".join(messages[0:i])))
    else:
        scontent.append(str(":::".join(messages[i-10:i])))
    rcontent.append(str(messages[i]))
    #print
    sentiment.append('Neu')
    annotation_status.append('N')
    s1.append('s1')
    s2.append('s1')
    r1.append('s1')
    r2.append('s1')
    category.append('IMIP')

hello = {'PairId':pairId, 'scontent': scontent, 'rcontent': rcontent, 's1':s1, 's2':s2, 'r1':r1, 'r2': r2, 'sentiment':sentiment, 'annotation_status': annotation_status, 'category': category}
df_data = pd.DataFrame(hello)


dictionary={}
for index, elem in enumerate(pairId):
    dictionary[elem]={}
    dictionary[elem]['s_content']=scontent[index]
    dictionary[elem]['r_content']=scontent[rcontent]