import os

import mysql.connector
import pickle
from django.shortcuts import render
from django.http import HttpResponse
import json
from django.core.files.storage import FileSystemStorage

from random import shuffle
# from dishelper.settings import BASE_DIR

# import tarfile
# from io import BytesIO

# print('Connected to Database')

def highlight_responder(request):
	if request.method == 'POST':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()

		refresh = request.POST.get('refresh', None)

		pair_Id = request.POST.get('pair_Id', None)
		s_content = request.POST.get('s_content', None)
		r_content = request.POST.get('r_content', None)
		userName = request.POST.get('userName', None)

		if refresh == 'T':
			return_dict = {'out': [pair_Id, s_content, r_content, userName],
					 	'IAIP': request.POST.get('IAIP', None),
					 	'IAIS': request.POST.get('IAIS', None),
					 	'IMP': request.POST.get('IMP',None),
					 	'IMS': request.POST.get('IMS',None),
					 	'IHLP': request.POST.get('IHLP',None),
						'IHLS': request.POST.get('IHLS',None),
						'IPLP': request.POST.get('IPLP',None),
						'IPLS': request.POST.get('IPLS',None),
						'IOIP': request.POST.get('IOIP',None),
						'IOIS': request.POST.get('IOIS',None),
						'EE': request.POST.get('EE',None),
						'EIH': request.POST.get('EIH',None),
						'ENF': request.POST.get('ENF',None),
						'EEH': request.POST.get('EEH',None),
						'GW': request.POST.get('GW',None),
						'GCSI': request.POST.get('GCSI',None),
						'GCG': request.POST.get('GCG',None),
						'ACK': request.POST.get('ACK',None),
						'OTH': request.POST.get('OTH',None)}

			return render(request, "app/highlight_responder.html", return_dict)

		IAIP = request.POST.get('IAIP', None)
		IAIS = request.POST.get('IAIS', None)
		IMP = request.POST.get('IMP', None)
		IMS = request.POST.get('IMS', None)
		IHLP = request.POST.get('IHLP', None)
		IHLS = request.POST.get('IHLS', None)
		IPLP = request.POST.get('IPLP', None)

		IPLS = request.POST.get('IPLS', None)
		IOIP = request.POST.get('IOIP', None)
		IOIS = request.POST.get('IOIS', None)
		EE = request.POST.get('EE', None)
		EIH = request.POST.get('EIH', None)
		ENF = request.POST.get('ENF', None)
		EEH = request.POST.get('EEH', None)
		GW = request.POST.get('GW', None)
		GCSI = request.POST.get('GCSI', None)
		GCG = request.POST.get('GCG', None)
		ACK = request.POST.get('ACK', None)
		OTH = request.POST.get('GCG', None)

		print("Happiness", EEH)
		
		IAI_L = request.POST.getlist('informational', None)
		IHL_L = request.POST.getlist('instrumental', None)
		IPL_L = request.POST.getlist('emotional', None)
		IMP_L = request.POST.getlist('esteem', None)
		IOI_L = request.POST.getlist('network', None)

		ENF_L = request.POST.getlist('likings', None)
		EIH_L = request.POST.getlist('hope', None)
		EE_L = request.POST.getlist('empathy', None)
		EEH_L = request.POST.getlist('happiness', None)

		GW_L = request.POST.getlist('group', None)

		GCSI_L = request.POST.getlist('interaction', None)
		GCSG_L = request.POST.getlist('greeting', None)
		ACK_L = request.POST.getlist('ack', None)
		
		sql = "DELETE FROM PILOT_A1_Category_Highlight WHERE PairId = " + pair_Id
		mycursor.execute(sql)

		
		if IAI_L!=None:
			for elem in IAI_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IAI')
				mycursor.execute(sql, val)

		if IHL_L!=None:
			for elem in IHL_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IHL')
				mycursor.execute(sql, val)

		if IMP_L!=None:
			for elem in IMP_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IMP')
				mycursor.execute(sql, val)

		if IPL_L!=None:
			for elem in IPL_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IPL')
				mycursor.execute(sql, val)

		if IOI_L!=None:
			for elem in IOI_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'IOI')
				mycursor.execute(sql, val)

		if ENF_L!=None:
			for elem in ENF_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'ENF')
				mycursor.execute(sql, val)

		if EE!=None:
			for elem in IAI:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'EE')
				mycursor.execute(sql, val)

		if EIH_L!=None:
			for elem in EIH_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'EIH')
				mycursor.execute(sql, val)

		if EEH_L!=None:
			for elem in EEH_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'EEH')
				mycursor.execute(sql, val)

		if GW_L!=None:
			for elem in GW_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'GW')
				mycursor.execute(sql, val)

		if GCSI_L!=None:
			for elem in GCSI_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'GCSI')
				mycursor.execute(sql, val)

		if GCSG_L!=None:
			for elem in GCSG_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'GCG')
				mycursor.execute(sql, val)

		if ACK_L!=None:
			for elem in ACK_L:
				sql = "INSERT INTO PILOT_A1_Category_Highlight (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'ACK')
				mycursor.execute(sql, val)

		mydb.commit()
		mycursor.close()

		return_dict = {'out': [pair_Id, s_content, r_content, userName],
					 	'IAIP': IAIP,
					 	'IAIS': IAIS, 
					 	'IMP': IMP,
					 	'IMS': IMS,
					 	'IHLP': IHLP,
						'IHLS': IHLS,
						'IPLP': IPLP,
						'IPLS': IPLS,
						'IOIP': IOIP,
						'IOIS': IOIS,
						'EE': EE,
						'EIH': EIH,
						'ENF': ENF,
						'EEH': EEH,
						'GW': GW,
						'GCSI': GCSI,
						'GCG': GCG,
						'ACK': ACK,
						'OTH': OTH}

		return render(request, "app/highlight_responder.html", return_dict)
	else:
		pair_Id = request.GET.get('pair_Id', None)
		s_content = request.GET.get('s_content', None)
		r_content = request.GET.get('r_content', None)
		userName = request.GET.get('userName', None)
		return_dict = {'out': [pair_Id, s_content, r_content]}
		return render(request, "app/highlight_responder.html", return_dict)


def highlight_seeker(request):
	if request.method == 'POST':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()
		pair_Id = request.POST.get('pair_Id', None)
		s_content = request.POST.get('s_content', None)
		r_content = request.POST.get('r_content', None)
		userName = request.POST.get('userName', None)

		S_info = request.POST.getlist('Info', None)
		S_emotion = request.POST.getlist('emotion', None)
		S_chitchat = request.POST.getlist('chitchat', None)

		acknowledgement = request.POST.get('ack', None)
		group_work = request.POST.get('gw', None)
		others = request.POST.get('oth', None)
		sentiment = request.POST.get('Mental_Health', None)
		print(sentiment, acknowledgement, group_work, S_info)

		IAIS=0
		IAIP=0
		IMPIS=0
		IMPIP=0
		IHLIP=0
		IHLIS=0
		IPLS=0
		IPLP=0
		IOIP=0
		IOIS=0

		EE=0
		EH=0
		EHP=0
		EN=0

		GW=group_work
		GCSI=0
		GCSG=0
		ACK=acknowledgement
		OTH=others

		mycursor = mydb.cursor()
		sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IAIP='F', IAIS='F',  IMP='F', IMS='F', IHLP='F', IHLS='F', IPLP='F', IPLS='F', IOIP='F', IOIS='F', EE='F', EIH='F', ENF='F', EEH='F', GW='F', GCSI='F', GCG='F', ACK='F', OTH='F' WHERE PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		for tag in S_info:
			if(tag == 'AdminS'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IAIS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IAIS=1
			
			if(tag == 'AdminP'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IAIP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IAIP=1
			
			if(tag == 'MedicalS'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IMS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IMPIS=1
			
			if(tag == 'MedicalP'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IMP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IMPIP=1

			if(tag == 'PLifeS'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IPLS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IPLS=1

			if(tag == 'PLifeP'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IPLP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IPLP=1
			
			if(tag == 'HLifeS'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IHLS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IHLIS=1

			if(tag == 'HLifeP'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IHLP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IHLIP=1
			
			if(tag == 'OtherInfoS'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IOIS = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IOIS=1

			if(tag == 'OtherInfoP'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET IOIP = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				IOIP=1

		for tag in S_emotion:
			if(tag == 'Empathy'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET EE = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				EE=1

			if(tag == 'Hope'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET EIH = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				EH=1

			if(tag == 'Happiness'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET EEH = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				EHP=1

			if(tag == 'Negative'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET ENF = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				EN=1

		for tag in S_chitchat:
			if(tag == 'Social'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET GCSI = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				GCSI=1

			if(tag == 'greet'):
				mycursor = mydb.cursor()
				mycursor.execute(sql)
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET GCG = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				mydb.commit()
				mycursor.close()
				GCSG=1

		
		if(ACK=='1'):
			mycursor = mydb.cursor()
			mycursor.execute(sql)
			sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET ACK = 'T' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
			mydb.commit()
			mycursor.close()

		if(GW=='1'):
			mycursor = mydb.cursor()
			mycursor.execute(sql)
			sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET GW = 'T' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
			mydb.commit()
			mycursor.close()

		if(OTH=='1'):
			mycursor = mydb.cursor()
			mycursor.execute(sql)
			sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET OTH = 'T' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
			mydb.commit()
			mycursor.close()
			
		
		print(ACK, type(ACK), GW, type(GW), OTH, type(OTH))

		return_dict = {'out': [pair_Id, s_content, eval(r_content)[1]['Message'], userName],
					 	'IAIP': IAIP,
					 	'IAIS': IAIS, 
					 	'IMPIS': IMPIS,
					 	'IMPIP': IMPIP,
					 	'IHLIP': IHLIP,
						'IHLIS': IHLIS,
						'IPLP': IPLP,
						'IPLS': IPLS,
						'IOIP': IOIP,
						'IOIS': IOIS,
						'EE': EE,
						'EH': EH,
						'EN': EN,
						'EHP': EHP,
						'GW': GW,
						'GCSI': GCSI,
						'GCSG': GCSG,
						'ACK': ACK,
						'OTH': OTH}
		return render(request, "app/highlight_seeker.html", return_dict)



def support_characteristics(request):

	if request.method == 'POST':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()

		S_Post = request.POST.getlist('S_Post', None)

		print('S_Post:', S_Post, type(S_Post))

		pair_Id = request.POST.get('pair_Id', None)
		s_content = request.POST.get('s_content', None)
		r_content = request.POST.get('r_content', None)
		sentiment = request.POST.get('Mental_Health', None)
		userName = request.POST.get('userName', None)
		newTopic = request.POST.get('newTopic', None)

		print('pair_Id:', pair_Id)
		print('Sentiment:',sentiment)
		#print('s_content:', eval(s_content), len(eval(s_content)))
		if sentiment == 'Negative':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET Sentiment = 'N' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		elif sentiment == 'Positive':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET Sentiment = 'P' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		elif sentiment == 'Neutral':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET Sentiment = 'Neu' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)


		if newTopic == 'Yes':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET newtopic = 'T' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		elif newTopic == 'No':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET newtopic = 'F' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		

		mydb.commit()
		mycursor.close()

		info=0
		emo=0
		gc=0
		gw=0
		oth=0
		ack=0
		mycursor = mydb.cursor()
		for s_tag in S_Post:
			if(s_tag=='Informational'):
				info=1

			if(s_tag=='Emotional'):
				emo=1
			
			if(s_tag=='Group Work'):
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET GW = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				gw=1

			if(s_tag=='General Chit-Chat'):
				gc=1

			if(s_tag=='Others'):
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET OTH = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				oth=1

			if(s_tag=='Acknowledgement'):
				sql = "UPDATE PILOT_A1_MESSAGE_CATEGORIES SET ACK = 'T' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)
				ack=1


		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		if sentiment == 'Negative':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET Sentiment = 'N' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		if sentiment == 'Positive':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET Sentiment = 'P' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		else:
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET Sentiment = 'Neu' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)

		if newTopic == 'Yes':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET newtopic = 'T' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)
		elif newTopic == 'No':
			sql = "UPDATE PILOT_A1_Sentiment_Messages SET newtopic = 'F' WHERE PairId = " + str(pair_Id)
			mycursor.execute(sql)

		final={}
	
		for key, value in eval(s_content).items():
			final[key]={}
			for i, j in value.items():
				final[key][i]=j

		s_content=final
		print("Final", final)

		#target = curr_pair[2]
		r_content=r_content.split(":::")
		final={}
		for index, elem in enumerate(r_content):
			#print(index, elem)
			final[index+1]={}
			final[index+1]['Date']=eval(elem)[index+1]['Date']
			final[index+1]['Time']=eval(elem)[index+1]['Time']
			final[index+1]['User']=eval(elem)[index+1]['User']
			final[index+1]['Message']=eval(elem)[index+1]['Message']

		r_content=final

		return_dict = {'out': [pair_Id, s_content, r_content, userName],
					 	'ack': ack,
					 	'gw': gw, 
					 	'gc': gc,
					 	'info': info,
					 	'emo': emo, 'oth': oth}

		return render(request, "app/support_characteristics.html", return_dict)


def post_characteristics(request):
    #return HttpResponse('Hello world !')
    
	if request.method == 'GET':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()
		pair_Id = request.GET.get('post')
		flag = request.GET.get('flag')
		mycursor = mydb.cursor()
		sql="SELECT PairId from PILOT_A1_Messages WHERE annotation_status='N'"
		mycursor.execute(sql)
		results=mycursor.fetchall()
		pairs=[]
		for elem in results:
			#print(elem, str(elem)[1:-2])
			pairs.append(str(elem)[1:-2])
			
		#print(pairs)
		if(flag=='1'):
			pair_Id=pair_Id
		else:
			pair_Id=pairs[0]
			
		
		#print(pair_Id)

		
		userName = request.GET.get('userName')
		mycursor.execute("SELECT PairId, S_Content, R_Content, annotation_status FROM PILOT_A1_Messages WHERE PairId = " + str(pair_Id))
		myresult = mycursor.fetchall()
		#for elem in myresult:
			#print(elem)
		#shuffle(myresult)
		
		curr_pair = myresult[0]
		with open('dict.pickle', 'rb') as handle:
			dictionary = pickle.load(handle)

		pair_id = curr_pair[0]
		previous = curr_pair[1]
		#s_content=previous.split(":::")[0:]
		s_content = dictionary[pair_id]['s_content'].split(":::")[0:]

		final={}
		for index, elem in enumerate(s_content):
			print(index, elem)
			try:
				final[index+1]={}
				final[index+1]['Date']=elem.split(";")[0]
				final[index+1]['Time']=elem.split(";")[1]
				final[index+1]['User']=elem.split(";")[2]
				final[index+1]['Message']=elem.split(";")[3]
			except:
				final[index+1]={}
				final[index+1]['Date']=" "
				final[index+1]['Time']=" "
				final[index+1]['User']=" "
				final[index+1]['Message']=" "

		s_content=final

		#target = curr_pair[2]
		#r_content=target.split(":::")
		r_content = dictionary[pair_id]['r_content'].split(":::")[0:]

		final={}
		for index, elem in enumerate(r_content):
			#print(index, elem)
			final[index+1]={}
			final[index+1]['Date']=elem.split(";")[0]
			final[index+1]['Time']=elem.split(";")[1]
			final[index+1]['User']=elem.split(";")[2]
			final[index+1]['Message']=elem.split(";")[3]

		r_content=final
		annotation_status = curr_pair[3]

		mycursor.close()
		
		#return render(request, "app/post_characteristics.html", {'out': '', 'annotation_status': annotation_status})
		return render(request, "app/post_characteristics.html", {'out': [pair_id, s_content, r_content, userName, flag], 'annotation_status': annotation_status})

	else:
		return render(request, "app/post_characteristics.html", {'out': ['pair_id', 's_content', 'r_content', 'userName', 'flag']})
    
    
def login(request):
	if request.method == 'GET':
		mydb = mysql.connector.connect(host="localhost",user="root",passwd="Ishani@340",port = 3306, database='HIV_Africa')
		return render(request, 'app/login.html')
	else:
		return render(request, 'app/login.html')



def success(request):
	if request.method == 'POST':

		mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )

		mycursor = mydb.cursor()

		pair_Id = request.POST.get('pair_Id', None)
		s_content = request.POST.get('s_content', None)
		r_content = request.POST.get('r_content', None)

		skip = request.POST.get('skip', None)

		if skip == 'T':
			print('Skipping!')
			skip_reason = request.POST.getlist('skip_annotation', None)
			class_suggestion = request.POST.get('class_suggestion', None)

			if skip_reason != None:
				reasons = ''

				for elem in skip_reason:
					reasons = str(elem) + ',' + reasons.strip()

				sql = "DELETE FROM PILOT_A1_SkipReason WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)

				if class_suggestion == None:
					class_suggestion = ''


				sql = "INSERT INTO PILOT_A1_SkipReason (PairId, Reason, Class_Suggestion) VALUES (%s, %s, %s)"
				val = (pair_Id, reasons, class_suggestion)
				mycursor.execute(sql, val)

				sql = "UPDATE PILOT_A1_Messages SET annotation_status = 'P' WHERE PairId = " + str(pair_Id)
				mycursor.execute(sql)

				mydb.commit()
				mycursor.close()

				return render(request, "app/success.html", {'out': [pair_Id, s_content, r_content], 'next': int(pair_Id) + 1, 'success_type': 'Annotation Skipped!'})

		mycursor = mydb.cursor()
		sql = "UPDATE PILOT_A1_Messages set annotation_status='Y' where PairId = " + str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()

		R_English = request.POST.getlist('informational', None)
		R_Swahili = request.POST.getlist('emotional', None)
		R_Sheng = request.POST.getlist('instrumental', None)
		R_Other = request.POST.getlist('esteem', None)
		R_Cm = request.POST.getlist('cm', None)

		mycursor = mydb.cursor()

		sql = "DELETE From PILOT_A1_Language_Annotation where PairId = "+str(pair_Id)
		mycursor.execute(sql)
		mydb.commit()
		mycursor.close()


		mycursor = mydb.cursor()
		if R_English != None:
			for elem in R_English:
				sql = "INSERT INTO PILOT_A1_Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'English')
				mycursor.execute(sql, val)

		if R_Swahili != None:
			for elem in R_Swahili:
				sql = "INSERT INTO PILOT_A1_Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id,  elem, 'Swahili')
				mycursor.execute(sql, val)

		if R_Sheng != None:
			for elem in R_Sheng:
				sql = "INSERT INTO PILOT_A1_Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s, %s)"
				val = (pair_Id, elem, 'Sheng')
				mycursor.execute(sql, val)

		if R_Other != None:
			for elem in R_Other:
				sql = "INSERT INTO PILOT_A1_Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s,%s)"
				val = (pair_Id, elem, 'Other')
				mycursor.execute(sql, val)
			other_reason = request.POST.get('reason_specify', None)
			others_choose= request.POST.get('Others', None)
			if(others_choose=='NE'):
				other_reason=''
			elif(others_choose=='IDK'):
				other_reason=''
			else:
				other_reason='The primary Reason is: '+other_reason
			print(others_choose, other_reason)
		
			sql="DELETE FROM PILOT_A1_Other_Language_Reason where PairId="+str(pair_Id)
			mycursor.execute(sql)

			sql = "INSERT INTO PILOT_A1_Other_Language_Reason (PairId, choice, reason) VALUES (%s, %s,%s)"
			val = (pair_Id, others_choose, other_reason)
			mycursor.execute(sql, val)

			
		if R_Cm != None:
			for elem in R_Cm:
				sql = "INSERT INTO PILOT_A1_Language_Annotation (PairId, C_Highlighted, Tag) VALUES (%s, %s,%s)"
				val = (pair_Id, elem, 'Code-mixed word')
				mycursor.execute(sql, val)
		
		
		mydb.commit()
		mycursor.close()

        ## Display in the table whatever is present
		mycursor = mydb.cursor()
		sql="Select sentiment from PILOT_A1_Sentiment_Messages where PairId="+str(pair_Id)
		mycursor.execute(sql)
		sentiment = mycursor.fetchall()
		final_sentiment=str(sentiment[0])[2:-3]
		mydb.commit()
		mycursor.close()

		mycursor = mydb.cursor()
		sql="Select newtopic from PILOT_A1_Sentiment_Messages where PairId="+str(pair_Id)
		mycursor.execute(sql)
		newtopic = mycursor.fetchall()
		mydb.commit()
		mycursor.close()

		## Display in the table whatever is present
		mycursor = mydb.cursor()
		sql="Select * from PILOT_A1_MESSAGE_CATEGORIES where PairId="+str(pair_Id)
		mycursor.execute(sql)
		categories = mycursor.fetchall()
		#print(str(categories).split(",")[1][2:-1])
		mydb.commit()
		mycursor.close()
		
		cat_dict={'IAIP':'F', 'IAIS':'F', 'IMP':'F', 'IMS':'F', 'IHLP':'F', 'IHLS':'F',
				'IPLP':'F', 'IPLS':'F','IOIP':'F', 'IOIS':'F', 'EE':'F', 'EIH':'F', 
				'ENF':'F', 'EEH':'F', 'GW':'F', 'GCSI':'F', 'GCG':'F', 'ACK':'F', 'OTH':'F'}
			
		if(str(categories).split(",")[1][2:-1]=='T'):
			cat_dict['Provide Admin Info']='T'
		if(str(categories).split(",")[2][2:-1]=='T'):
			cat_dict['Seek Admin Info']='T'
		if(str(categories).split(",")[3][2:-1]=='T'):
			cat_dict['Provide Medical Info']='T'
		if(str(categories).split(",")[4][2:-1]=='T'):
			cat_dict['Seek Medical Info']='T'

		if(str(categories).split(",")[5][2:-1]=='T'):
			cat_dict['Provide Lifestyle Info']='T'
		if(str(categories).split(",")[6][2:-1]=='T'):
			cat_dict['Seek Lifestyle Info']='T'
		if(str(categories).split(",")[7][2:-1]=='T'):
			cat_dict['Provide Personal Life Info']='T'
		if(str(categories).split(",")[8][2:-1]=='T'):
			cat_dict['Seek Personal Life Info']='T'
		if(str(categories).split(",")[9][2:-1]=='T'):
			cat_dict['Provide Other Info']='T'
		if(str(categories).split(",")[10][2:-1]=='T'):
			cat_dict['Seek Other Info']='T'
		if(str(categories).split(",")[11][2:-1]=='T'):
			cat_dict['Provide Empathy']='T'
		if(str(categories).split(",")[12][2:-1]=='T'):
			cat_dict['Encouraging to be hopeful']='T'
		if(str(categories).split(",")[13][2:-1]=='T'):
			cat_dict['Express Negative Feeling']='T'
		if(str(categories).split(",")[14][2:-1]=='T'):
			cat_dict['Express Happiness']='T'
		if(str(categories).split(",")[15][2:-1]=='T'):
			cat_dict['Group Work']='T'
		if(str(categories).split(",")[16][2:-1]=='T'):
			cat_dict['General Chit-chat Social Interaction']='T'
		if(str(categories).split(",")[17][2:-1]=='T'):
			cat_dict['Greetings']='T'
		if(str(categories).split(",")[18][2:-1]=='T'):
			cat_dict['Acknowledgement']='T'
		if('T' in str(categories).split(",")[19][2:-1]):
			cat_dict['Others']='T'

		final_categories=[]
		for k, v in cat_dict.items():
			if(v=='T'):
				final_categories.append(k)
					
		sentiment_dict={'P':'Positive', 'N':'Negative', 'Neu': 'Neutral'}
		

		language_dict={}
		language_dict['English']=[]
		language_dict['Swahili']=[]
		language_dict['Sheng']=[]
		language_dict['Other']=[]
		language_dict['Code-mixed word']=[]

		## Display in the table whatever is present
		mycursor = mydb.cursor()
		sql="Select C_Highlighted, Tag from PILOT_A1_Language_Annotation where PairId="+str(pair_Id)
		mycursor.execute(sql)
		languages = mycursor.fetchall()
		for i in range(len(languages)):
			print(languages[i][1])
			if(languages[i][1]=='English'):
				language_dict['English'].append(languages[i][0])
			if(languages[i][1]=='Swahili'):
				language_dict['Swahili'].append(languages[i][0])
			if(languages[i][1]=='Sheng'):
				language_dict['Sheng'].append(languages[i][0])
			if(languages[i][1]=='Other'):
				language_dict['Other'].append(languages[i][0])
			if(languages[i][1]=='Code-mixed word'):
				language_dict['Code-mixed word'].append(languages[i][0])
			
		mydb.commit()
		mycursor.close()

		#print(sentiment_dict[final_sentiment],final_categories, language_dict)

		final_output={}

		final_output['Message']=r_content
		final_output['Sentiment']=sentiment_dict[final_sentiment]
		final_output['Categories']=final_categories
		final_output['Language']=language_dict
		final_output['newTopic']=newtopic

		
		### Fetch from the Tables

		mycursor = mydb.cursor()
		sql="Select PairId, sentiment, R_Content from PILOT_A1_Messages where annotation_status='Y'"
		mycursor.execute(sql)
		results = mycursor.fetchall()
		mydb.commit()
		mycursor.close()

		results_dict={}
		pairs=[]
		for elem in results:
			#print(elem)
			pairs.append(elem[0])
			results_dict[elem[0]]={}
			results_dict[elem[0]]['message']=elem[2].split(";")[-1]
			#results_dict[elem[0]]['sentiment']=elem[1]

		## Finding the Sentiment
		for pair in pairs:
			mycursor = mydb.cursor()
			sql="Select sentiment from PILOT_A1_Sentiment_Messages where pairId="+str(pair)
			mycursor.execute(sql)
			result = mycursor.fetchall()
			#print(result)
			mydb.commit()
			mycursor.close()
			results_dict[pair]['sentiment']=result
		
		#print(results_dict)

		### Finding the Categories
		cat_dict={}
		for pair in pairs:
			mycursor = mydb.cursor()
			sql="Select * from PILOT_A1_MESSAGE_CATEGORIES where PairId="+str(pair)
			mycursor.execute(sql)
			categories = mycursor.fetchall()
			mydb.commit()
			mycursor.close()
			cat_dict[pair]={}
			if(str(categories).split(",")[1][2:-1]=='T'):
				cat_dict[pair]['Provide Admin Info']='T'
			if(str(categories).split(",")[2][2:-1]=='T'):
				cat_dict[pair]['Seek Admin Info']='T'
			if(str(categories).split(",")[3][2:-1]=='T'):
				cat_dict[pair]['Provide Medical Info']='T'
			if(str(categories).split(",")[4][2:-1]=='T'):
				cat_dict[pair]['Seek Medical Info']='T'

			if(str(categories).split(",")[5][2:-1]=='T'):
				cat_dict[pair]['Provide Lifestyle Info']='T'
			if(str(categories).split(",")[6][2:-1]=='T'):
				cat_dict[pair]['Seek Lifestyle Info']='T'
			if(str(categories).split(",")[7][2:-1]=='T'):
				cat_dict[pair]['Provide Personal Life Info']='T'
			if(str(categories).split(",")[8][2:-1]=='T'):
				cat_dict[pair]['Seek Personal Life Info']='T'
			if(str(categories).split(",")[9][2:-1]=='T'):
				cat_dict[pair]['Provide Other Info']='T'
			if(str(categories).split(",")[10][2:-1]=='T'):
				cat_dict[pair]['Seek Other Info']='T'
			if(str(categories).split(",")[11][2:-1]=='T'):
				cat_dict[pair]['Provide Empathy']='T'
			if(str(categories).split(",")[12][2:-1]=='T'):
				cat_dict[pair]['Encouraging to be hopeful']='T'
			if(str(categories).split(",")[13][2:-1]=='T'):
				cat_dict[pair]['Express Negative Feeling']='T'
			if(str(categories).split(",")[14][2:-1]=='T'):
				cat_dict[pair]['Express Happiness']='T'
			if(str(categories).split(",")[15][2:-1]=='T'):
				cat_dict[pair]['Group Work']='T'
			if(str(categories).split(",")[16][2:-1]=='T'):
				cat_dict[pair]['General Chit-chat Social Interaction']='T'
			if(str(categories).split(",")[17][2:-1]=='T'):
				cat_dict[pair]['Greetings']='T'
			if(str(categories).split(",")[18][2:-1]=='T'):
				cat_dict[pair]['Acknowledgement']='T'
			if('T' in str(categories).split(",")[19][2:-1]):
				cat_dict[pair]['Others']='T'
			#print(cat_dict)
		final_categories={}
		for k, vals in cat_dict.items():
			final_categories[k]=[]
			for cat, flag in vals.items():
				if(flag=='T'):
					final_categories[k].append(cat)

		
		
		#print("Final Categories:"+str(final_categories))


		for key, val in final_categories.items():
			results_dict[key]['category']=val
		
		#print("==========================")
		#print(results_dict)
		#print("==========================")
		
		
		### Finding the languages
		language_dict={}
		for pair in pairs:
			mycursor = mydb.cursor()
			sql="Select C_Highlighted, Tag from PILOT_A1_Language_Annotation where PairId="+str(pair)
			mycursor.execute(sql)
			languages = mycursor.fetchall()
			#print(languages)
			language_dict[pair]={}
			language_dict[pair]['English']=[]
			language_dict[pair]['Swahili']=[]
			language_dict[pair]['Sheng']=[]
			language_dict[pair]['Other']=[]
			language_dict[pair]['Code-mixed word']=[]
			
			for i in range(len(languages)):
				
				#print(languages[i], i)
				if(languages[i][1]=='English'):
					language_dict[pair]['English'].append(languages[i][0])
				if(languages[i][1]=='Swahili'):
					language_dict[pair]['Swahili'].append(languages[i][0])
				if(languages[i][1]=='Sheng'):
					language_dict[pair]['Sheng'].append(languages[i][0])
				if(languages[i][1]=='Other'):
					language_dict[pair]['Other'].append(languages[i][0])
				if(languages[i][1]=='Code-mixed word'):
					language_dict[pair]['Code-mixed word'].append(languages[i][0])
				
			mydb.commit()
			mycursor.close()
		
		final_languages={}
		for k, vals in language_dict.items():
			final_languages[k]=vals

		#print(final_languages)

		for key, val in final_languages.items():
			results_dict[key]['language']=val

		#(results_dict)

		table_json={'1': {'Sentence': 'Hello', 'Sentiment': 'N', 'Category': 'P', 'Language': 'Eng'}, '2': {'Sentence': 'Hello', 'Sentiment': 'N', 'Category': 'P', 'Language': 'Eng'}}
		return render(request, "app/success.html", {'out': [pair_Id, s_content, r_content, final_output], 'next': int(pair_Id) + 1, 'success_type': 'Annotation Successful!','table_json':results_dict})

'''
def pieChart(request):
	if request.method == 'GET':
		table_json=request.GET.get('table_json')
		print(table_json)
		return render(request, 'app/pieChart.html',{'out': [table_json]})
	else:
		table_json=request.POST.get('table_json')
		print(table_json)
		return render(request, 'app/pieChart.html',{'out': [table_json]})


def pieChart(request):
	if request.method == 'POST':
		table_json=request.POST.get('table_json')
		#print(table_json)
		return_dict = {'out': [table_json]}
		return render(request, "app/pieChart2.html", return_dict)

'''

def pieChart(request):
	if request.method == 'POST':
		table_json=request.POST.get('table_json')
		#print(table_json)
		return_dict = {'out': [eval(table_json)]}
		return render(request, "app/pieChart2.html", return_dict)
