import mysql.connector

mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )


for i in range(18):
    if(i+1>1):
        #print(i+1)
        mycursor = mydb.cursor()
        sql = "INSERT INTO MESSAGE_CATEGORIES (PairId, IAIP, IAIS, IMP, IMS, IHLP, IHLS, IPLP, IPLS, IOIP, IOIS, EE, EIH, ENF, EEH, GW, GCSI, GCG, ACK, OTH) values (%s, %s, %s, %s,%s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        val = (i+1, 'F', 'F', 'F','F' ,'F', 'F', 'F', 'F', 'F', 'F','F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F')
        mycursor.execute(sql,val)
        mydb.commit()
        mycursor.close()

