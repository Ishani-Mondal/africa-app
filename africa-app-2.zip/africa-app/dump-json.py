
import json 
dict={1: {'Sentence':'Hello everyone myself Ishani', 'Sentiment':'Non-negative', 'Category': 'Intro', 'Language':'English'},
	  2: {'Sentence':'Hello everyone myself Sombuddha', 'Sentiment':'Non-negative', 'Category': 'Intro', 'Language':'English'},
	  3 : {'Sentence':'I am having backpain and feeling sick today', 'Sentiment':'Negative', 'Category': 'Health', 'Language':'English'},
	  4 : {'Sentence':'Mujhe Ladakh jana hain', 'Sentiment':'Non-negative', 'Category': 'Place', 'Language':'Hindi'},
	  5 : {'Sentence':'Ami Ladakh jete chai', 'Sentiment':'Non-negative', 'Category': 'Place', 'Language':'Bengali'}}

json_object = json.dumps(dict)

with open("sample.json", "w") as outfile: 
    outfile.write(json_object) 