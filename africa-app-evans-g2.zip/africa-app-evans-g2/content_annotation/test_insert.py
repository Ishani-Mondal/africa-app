import pandas as pd
df = pd.read_excel (r'Smiley_Test.xlsx')
messages=[]
for index, row in df.iterrows():
    #if(index>2):
    messages.append(str(row['Date'])+";"+str(row['Time'])+";"+str(row['Sender'])+";"+str(row['Message']))

    
pairId=[]
scontent=[]
rcontent=[]
s1=[]
r1=[]
s2=[]
r2=[]
sentiment=[]
annotation_status=[]
category=[]


for i, elem in enumerate(messages):
    pairId.append(i+1)
    if(i<10):
        scontent.append(str(":::".join(messages[0:i])))
    else:
        scontent.append(str(":::".join(messages[i-10:i])))
    rcontent.append(str(messages[i]))
    #print
    sentiment.append('Neu')
    annotation_status.append('N')
    s1.append('s1')
    s2.append('s1')
    r1.append('s1')
    r2.append('s1')
    category.append('IMIP')
    #print(str(i)+"\t"+":::".join(messages[i-10:i])+"\t"+messages[i])
    
hello = {'PairId':pairId, 'scontent': scontent, 'rcontent': rcontent, 's1':s1, 's2':s2, 'r1':r1, 'r2': r2, 'sentiment':sentiment, 'annotation_status': annotation_status, 'category': category}
df_data = pd.DataFrame(hello)



import mysql.connector
mydb = mysql.connector.connect(
            host="52.187.63.154",
            user="ashish",
            passwd="me_health@2019",
            port = 3306,
            database='DEMO'
        )


for index, row in df_data.iterrows():
    print(type(row['rcontent']), row['rcontent'])
