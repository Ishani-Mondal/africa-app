#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd

df = pd.read_excel (r'G1_Feb.xlsx')
messages=[]
for index, row in df.iterrows():
    if(index>2):
        messages.append(str(row['Date'])+";"+str(row['Time'])+";"+str(row['Sender'])+";"+str(row['Message']))
        
#data = {'PairId': ['Amol', 'Lini'],
	#'s1': 'sdf',
#	'r1': 'dfs', 's2':'rwe', 'r2':'sds', 'scontent': " ", 'rcontent':" ", 'sentiment':'N', 'annotation_status':'F',
    #   'category':'IMIP'}

#df_data = pd.DataFrame(data)

pairId=[]
scontent=[]
rcontent=[]
s1=[]
r1=[]
s2=[]
r2=[]
sentiment=[]
annotation_status=[]
category=[]


for i, elem in enumerate(messages):
    pairId.append(i+1)
    if(i<10):
        scontent.append(str(":::".join(messages[0:i])))
    else:
        scontent.append(str(":::".join(messages[i-10:i])))
    rcontent.append(str(messages[i]))
    #print
    sentiment.append('Neu')
    annotation_status.append('N')
    s1.append('s1')
    s2.append('s1')
    r1.append('s1')
    r2.append('s1')
    category.append('IMIP')
    #print(str(i)+"\t"+":::".join(messages[i-10:i])+"\t"+messages[i])
    
hello = {'PairId':pairId, 'scontent': scontent, 'rcontent': rcontent, 's1':s1, 's2':s2, 'r1':r1, 'r2': r2, 'sentiment':sentiment, 'annotation_status': annotation_status, 'category': category}
df_data = pd.DataFrame(hello)


# In[3]:


import mysql.connector

mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="Ishani@340",
            port = 3306,
            database='HIV_Africa'
        )


for index, row in df_data.iterrows():
    mycursor = mydb.cursor()
    sql = "INSERT INTO PILOT_A1_Messages (PairId, S_PostId, R_PostId,  S_UserId, R_UserId, S_Content, R_Content, Sentiment, annotation_status, Category) values (%s, %s, %s, %s,%s, %s, %s, %s, %s, %s)"
    #print(row['rcontent'])
    val = (row['PairId'], row['s1'], row['r1'], row['s2'], row['r2'], str(row['scontent']), str(row['rcontent']), row['sentiment'], row['annotation_status'], row['category'])
    print(val)
    mycursor.execute(sql,val)
    mydb.commit()
    mycursor.close()



for index, row in df_data.iterrows():
    mycursor = mydb.cursor()
    sql = "INSERT INTO PILOT_A1_MESSAGE_CATEGORIES (PairId, IAIP, IAIS, IMP, IMS, IHLP, IHLS, IPLP, IPLS, IOIP, IOIS, EE, EIH, ENF, EEH, GW, GCSI, GCG, ACK, OTH) values (%s, %s, %s, %s,%s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    #print(row['rcontent'])
    val = (row['PairId'], 'F', 'F', 'F','F' ,'F', 'F', 'F', 'F', 'F', 'F','F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F')
    print(val)
    mycursor.execute(sql,val)
    mydb.commit()
    mycursor.close()


for index, row in df_data.iterrows():
    mycursor = mydb.cursor()
    sql = "INSERT INTO PILOT_A1_Sentiment_Messages (PairId, Sentiment,  newtopic) values (%s, %s, %s)"
    #print(row['rcontent'])
    val = (row['PairId'], 'Neu', 'F')
    print(val)
    mycursor.execute(sql,val)
    mydb.commit()
    mycursor.close()



