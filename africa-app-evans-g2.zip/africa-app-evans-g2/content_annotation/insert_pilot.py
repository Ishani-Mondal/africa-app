#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
df = pd.read_excel (r'G2-full.xlsx')
messages=[]
for index, row in df.iterrows():
    messages.append(str(row['Date'])+";"+str(row['Time'])+";"+str(row['Sender'])+";"+str(row['Message']))
        

pairId=[]
scontent=[]
rcontent=[]
s1=[]
r1=[]
s2=[]
r2=[]
sentiment=[]
annotation_status=[]
category=[]


for i, elem in enumerate(messages):
    pairId.append(i+1)
    if(i<10):
        scontent.append(str(":::".join(messages[0:i])))
    else:
        scontent.append(str(":::".join(messages[i-10:i])))
    rcontent.append(str(messages[i]))
    #print
    sentiment.append('Neu')
    annotation_status.append('N')
    s1.append('s1')
    s2.append('s1')
    r1.append('s1')
    r2.append('s1')
    category.append('IMIP')
    #print(str(i)+"\t"+":::".join(messages[i-10:i])+"\t"+messages[i])
    
hello = {'PairId':pairId, 'scontent': scontent, 'rcontent': rcontent, 's1':s1, 's2':s2, 'r1':r1, 'r2': r2, 'sentiment':sentiment, 'annotation_status': annotation_status, 'category': category}
df_data = pd.DataFrame(hello)

dictionary={}
for elem in pairId:
    dictionary[str(elem)]={}
    dictionary[str(elem)]['s_content']=scontent[pairId.index(elem)]
    dictionary[str(elem)]['r_content']=rcontent[pairId.index(elem)]

import json
with open('dictionary_file_for_phase2.json', 'w') as fp:
    json.dump(dictionary, fp)

print(len(dictionary))
import mysql.connector
mydb = mysql.connector.connect(
            host="52.187.63.154",
            user="ashish",
            passwd="me_health@2019",
            port = 3306,
            database='Final_HIV_Africa'
        )

#f=open('Values.txt','w')
for index, row in df_data.iterrows():
    mycursor = mydb.cursor()
    sql = "INSERT INTO Final_Demo_A2_Messages (PairId, annotation_status) values (%s, %s)"
    val = (row['PairId'], row['annotation_status'])
    mycursor.execute(sql, val)
    mydb.commit()
    mycursor.close()

for index, row in df_data.iterrows():
    mycursor = mydb.cursor()
    sql = "INSERT INTO Final_A2_MESSAGE_CATEGORIES (PairId, IAIP, IAIS, IMP, IMS, IHLP, IHLS, IPLP, IPLS, IOIP, IOIS, EE, EIH, ENF, EEH, GW, GCSI, GCG, ACK, OTH) values (%s, %s, %s, %s,%s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    val = (row['PairId'], 'F', 'F', 'F','F' ,'F', 'F', 'F', 'F', 'F', 'F','F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F')
    mycursor.execute(sql,val)
    mydb.commit()
    mycursor.close()


for index, row in df_data.iterrows():
    mycursor = mydb.cursor()
    sql = "INSERT INTO Final_A2_Sentiment_Messages (PairId, Sentiment,  newtopic) values (%s, %s, %s)"
    val = (row['PairId'], 'Neu', 'F')
    #print(val)
    mycursor.execute(sql,val)
    mydb.commit()
    mycursor.close()

